



Version 4 - The BUGGY release!

Home of Girlfriends, 
the Emperor Scorpion,
and the KRAKEN!

For Minecraft 1.6.2
Requires Forge for MC 1.6.2
Built and tested with Forge 9.10.0.804


YES! THE ORESPAWN MOD WORKS IN MULTIPLAYER.
YES! THERE IS A CONFIG OPTION TO CHANGE THE BLOCKID RANGE.
YES! THERE ARE CONFIG OPTIONS TO CHANGE THE DIMENSION IDS TOO.
YES! OreSpawn IS A MOD, NOT A MOD PACK!


OreSpawn uses Block/Item IDs in the range 2000-3500 by default.
OreSpawn uses Dimension IDs 10, 11, & 12 by default.
You can change these in the config file if there is a conflict.
The config file is created in the .minecraft/config directory the first time you run it.



GIRLFRIENDS!, ANCIENT ORE SPAWN, URANIUM AND TITANIUM,
ULTIMATE SWORDS, ULTIMATE ARMOR, ULTIMATE BOW, EYE OF ENDER BLOCKS,
POPCORN!,  CRITTER CAGES, LAVA EEL ARMOR, ENDERPEARL BLOCKS,
THE ULTIMATE FISHING ROD, MAGIC APPLES!, STRAWBERRY PLANTS,
FIRE FISH, APPLE COWS, MINER'S DREAM, AWESOME SOUND EFFECTS,
HOVERBOARDS, CORN PLANTS, CORNDOGS, MOTHS, BUTTERFLIES,
MOSQUITOS, and, and, and, OMG...  MOTHRA!

Fourty Five (45) NEW MOBS!
There's even a "WTF?" Mob!
AND A FEW WHOLE NEW WORLDS!!!

Plus

Emerald Armor, Emerald tools, Emerald Sword, Experience Armor,
Experience Sword, Experience Orb Catcher, DANCING GIRLFRIENDS,
a Freakin' Ray-Gun, Laser Charges, Experience Seed/plant and Tree,
and Lava Foam! Rubies! Ruby tools! Ruby Armor!Ruby Sword! 
And a THUNDERSTAFF! And, and, and,
"Holy Mother of Metal, Batman!" - EVIL ROBOTS!!!

Not to mention... Giant Lizards, Attack Squids and THE KRAKEN.

Ever fly a Cephadrome to kill a Kraken? Now you can!

Ever fly a Dragon, that shoots fireballs? Now you can!


New for Release 1.6.2.4

Bugs, bugs, bugs and more bugs!!!
Jumpy Bugs, Spit Bugs and Stink Bugs and more!
Butter Candy, Amethyst ore, Amethyst Armor, Amethyst Tools,
Gazelles, Chipmunks and Fireflies galore!

OH YES! 
OreSpawn now has that most glorious of all foods, ever -- BACON!
That's right! We have BACON!!!!

And lastly, something you've all been waiting for...
Something to make your days a whole lot brighter...
It's once again time to declare open season on Attack Squid...
Finally...

a KRAKEN REPELLENT!


And to top it all off... 
a rideable Ostrich!


Important Tweaks for Release 1.6.2.4

Toggle Girlfriend voices off/on with Ruby/Amethyst.
Uranium and Titanium ores smelt into nuggets.
Nine uranium/titanium nuggets make an ingot.
It now takes Blocks of uranium/titanium/iron to make an Ultimate Sword.
(Because it's so ridiculously over-powered!)
It now takes Blocks of uranium/titanium/iron to make an Ultimate Bow.
(Because it's so ridiculously over-powered!)
All other Ultimate items still craft with ingots.


Video Reviews:

GeneralSlippers
http://www.youtube.com/watch?v=gMBdLn-8wD0

TheAtlanticraft
https://www.youtube.com/watch?v=QvzovE426yw

Rabahrex - SPANISH
https://www.youtube.com/watch?v=6zhuITjz7_0

SevenPlaysTV - GERMAN
https://www.youtube.com/watch?v=2gWWZAaHmBA

FireTeen100 - RUSSIAN
https://www.youtube.com/watch?v=uAaKuq-1EP0


Howto:

Girlfriend Tips, by TheDiamondMinecart
https://www.youtube.com/watch?v=z6PPTRQWcLw

More Girlfriend tips, by JackSucksAtMinecraft
http://www.youtube.com/watch?v=0EKEeLdKLQc


Battle Royal:

Emperor Scorpion kicks some butt, by PopularMMOs
https://www.youtube.com/watch?v=2KAAtlKY3nA





CRAFTING RECIPIES


U = Uranium
T = Titanium
I = Iron
S = String
B = Bucket of Water
E = Ancient Dried Spawn Egg
R = Redstone
A = Apple
W = Wood of some sort
C = Cactus
G = Gunpowder
D = Diamond
. = empty


To Re-hydrate Ancient Dried Spawn Eggs:
...
.B.
.E.


Ultimate Sword:
.T.  --Titanium Block!
.U.  --Uranium Block!
.I.  --Iron Block!


Ultimate Pickaxe:
TUT
.U.
.I.


Ultimate Shovel:
.U.
.T.
.I.


Ultimate Hoe:
TU.
.I.
.I.


Ultimate Axe:
TU.
TI.
.I.


Ultimate Bow:
.TS  --Titanium Block!
I.S  --Iron Block!
.US  --Uranium Block!


Ultimate Helmet:
...
TIT
U.U


Ultimate Chestplate:
I.I
TTT
UUU


Ultimate Leggings:
III
T.T
U.U


Ultimate Boots:
...
T.T
U.U


Ultimate Fishing Rod:
..T
.IS
U.S


Magic Apple: (OMG! No! Don't!!!!)
RRR    <---Redstone BLOCK
RAR    <---Redstone BLOCK (middle is an apple)
RRR    <---Redstone BLOCK


Critter Cages: (W = STICKS!)
IWI
W.W
IWI


Hoverboard: (W = WOOD PLANKS!)
...
WWW
DRD


Lava Eel Armor:
Crafted the same as regular armor, just use Lava Eels instead!


Moth Scale Armor:
Same as regular armor, but you have to kill Mothra first!
This stuff looks seriously cool!


PopCorn:
Put corn in the furnace.

Butter:
Two buckets of milk on the crafting table.


Salt:
Salt Ore in the furnace.


Buttered Popcorn:
Popcorn and Butter on the crafting table.


Buttered and Salted Popcorn:
Buttered Popcorn and Salt on the crafting table.


Bag of Popcorn:
Six Buttered and Salted Popcorn, plus three Paper on the crafting table.


Miner's Dream !!!:
CCC    <- Cactus
RRR    <- Redstone BLOCK
GGG    <- Gunpowder


Raw Corn Dog:
Raw Chicken, Raw Pork, Corn, and a stick.


Cooked Corn Dog:
Put a raw corn dog in the furnace.
These things satisfy a serious amount of hunger for a long long time.


Uranium/Titanium Blocks:
Eye Of Ender Blocks:
EnderPearl Blocks:
Same as any other ingot-type block. Put nine on the crafting table.


Apple Tree Seed:
Place an Apple on the crafting table.


Extreme Torch:
Coal, Redstone, and a Stick on the crafting table.
Or, a regular torch and redstone.


Spider Web:
Eight strings arranged like wood for a chest will make you a spider web block!


Instant Stairs Up:
..C	(C is cobblestone)
.CG
CGG


Instant Stairs Down:
C..	(C is cobblestone)
GC.
GGC


Instant Stairs Accross:
...	(C is cobblestone)
CCC
GGG


Emerald Armor:
Same as regular armor, with emeralds.


Emerald Sword and Tools:
Same as regular sword and tools, with emeralds.
(If you like green, these look totally awesome!!!)


Ruby Armor:
Same as regular armor, with rubies.


Ruby Sword and Tools:
Same as regular sword and tools, with rubies.
(If you like red, these look totally awesome!!!)

Amethyst Sword and Tools:
Same as regular sword and tools, with Amethysts
(If you like purple, these look totally awesome!!!)


Experience Orb Catcher: (to make Bottles o' Enchanting)
.B. - empty bottle
.S. - string
.W. - stick


Experience Sword:
Emerald sword in the middle, surrounded by Bottles o' Enchanting.
(Emerald Sword must be NEW, not used)


Experience Armor:
Emerald armor piece in the middle, surrounded by Bottles o' Enchanting.
(Emerald Armor must be NEW, not used)


Experience Tree Seed:
Apple Tree Seed in the middle, surrounded by Bottles o' Enchanting.


To Reload a Ray-Gun:
Put one used Ray-Gun and one block of redstone on the crafting table.
Presto. Reloaded!


ThunderStaff:
R = Ruby
D = Diamond
. = Empty

DR.
RR.
..R


Butter Candy:
Butter, and sugar.


Raw Bacon:
Raw Pork, and salt.


Bacon:
Stick Raw Bacon in the furnace, and cook it!


Kraken Repellent:
S = string
E = Extreme Torch
D = Dead Stink Bug

D.D
SES
D.D


USEFUL ITEMS AND TIPS

Critter Cages only work about 80% of the time. You may have to throw more than one.  Keeps things interesting.  And yes, they catch almost all types of critters, including dragons! Very useful to simply transport farm animals. Also handy against creepers. Warning though... they work better on some critter than others!  Just throw one at an entity/mob to catch it.  Right-click it on the ground to release the captured critter. No, critter cages do not work on Robots. Yes, they work on big critters too, but very rarely.

Craft an Ultimate Fishing Rod and go fishing in Lava!!! You'll catch all sorts
	incedibly useful things. Including:
	Spark Fish
	Fire Fish
	Sun Fish
	Lava Eels
	and Sunspot Urchins.

The Ultimate Fishing Rod works great in water too! Try it!

Yes, I know. The fishing rod works kinda iffy. Not my code. It works just like the regular fishing rod. Find a bigger lava pool if you keep getting stuck on the bottom or sides. Some day I might rewrite it when I have time... sigh.

Lava Eels can be crafted into some pretty awesome armor.  Looks rather spectacular too, if you ask me! Seriously.  Lava Eel Armor is more durable than diamond, and fire resistant too!

Sunspot Urchins can and should be thrown! Try a few! A pyromaniacs dream come true...

To use an Ancient Dried Ore Spawn Egg, after you've re-hydrated it, just right-click with it on the ground. Ancient Dried Spawn Eggs can be mined/found only at shallow depths. Ancient Dried Spawn Eggs are actually fun to collect, and to spawn upon an unsuspecting friend! :) Ancient Dried Spawn Eggs have been updated to include all standard Minecraft critters. Can you find them all?

Catching Experience Orbs can be tricky. Don't even bother with ants. You have to catch significant experience. Kill something your own size. Try right clicking under the orb as it just passes into the block you're sighted on. You'll get the hang of it eventually. All you need is a little experience. Lol! I crack me up... :)

The Miner's Dream block is pretty damn cool! You've gotta try it! Make one. Take it underground, tap it on a stone block directly in front of you at your feet (not on a diagonal), and be amazed! 

Salt blocks kill ants. Great for keeping ants out of places you don't want them! Place a few Salt blocks in front of your door. Or, you can just dig up the Ant Blocks whenever you find them. That'll take care of most of them.

Extreme Torches are about 10% brighter than normal torches.

Emerald things are pretty durable. Definately worth making. And they look awesome! The Emerald pickaxe even has Silk Touch, so you can mine Ice Blocks to squelch the fire in your dragon!

Experience Armor is only active while you have an Experience Sword in your inventory or hotbar. Basically, just wearing it will give you experience... just for looking so cool...

An Experience sword gives you extra experience when hitting mobs. It also deals extra damage based on your experience level. It starts becoming fairly deadly once you get up over about level 20 or so.

Uranium and Titanium can be mined/found only deep underground. Uranium and Titanium require a diamond pick-axe to be mined. Yes, you need to find 3 diamonds and make a diamond pickaxe first. It's a pain, but believe me, it's worth it. Uranium and Titanium ore blocks are 'entangled'. Hit one and they all sparkle! Nine ingots of Uranium make a Uranium block. Same with Titanium. Cool, sparkley blocks...

Ultimate Armor is enchanted. Very useful. Awsome stuff and looks cool too!

Moth Scales can be crafted into some pretty darm cool armor too!

Did I mention the Lava Eel armor? Use Lava Eels to craft.

Yes. Yes you do want to make an Ultimate Sword. OMG. Way too cool.  In fact, you'll want to make two! One for you. One for your Girlfriend!

Ultimate tools wear out even slower than Diamond. They seem to last pretty much forever. One of each is probably all you'll need. 

Try an Ultimate Axe on a tree! Wow!

Ultimate Swords do only minimal damage to Players and Girlfriends.  (Yes, really. These things are so deadly I had to put code in to protect against accidents!) Although, you may still catch fire if you get hit...

Ultimate Bows (arrows) bounce off Players and Girlfriends for the same reason Ultimate Swords do only minimal damage. Otherwise, they're too deadly to use! Ultimate Bows will never run out of arrows. You don't even have to carry one in your inventory. Ultimate Bows need only be 'tapped' on the right mouse button. They shoot fast, like a semi-automatic!

Ultimate weapons and tools may not appear enchanted at first (if you cheat and get them in creative mode). They will auto-enchant on first use.

Oh yeah! Almost forgot. Lava Foam! Yeah! Wicked cool stuff! Slipperier than snot on a doorknob! Try walking on it. And bouncy bouncy bouncy. Run into it, and get bounced off. Gee, kind of like a pinball bumper... What would happen if you made a floor and walls of the stuff, and then put a Zombie or a few Enderman in it? I wonder... Lava Foam can only be found/mined near lots and lots of lava... somewhere like, the Nether!!!

Laser charges can be thrown. Please do. They're fun! :)

Ray-Guns and Laser Charges, being the advanced weapons that they are, were built to be ineffective on robots! Ray guns are sometimes dropped by the Robo-Warrior in the Rainbow Ant world.

Hoverboards are priceless for getting around in the Nether. Lava lakes? Feh. Who cares. Hop. Hover. Explore. 'W' for forward. 'S' to slow/reverse. SPACE for extra speed.

Have you tried the Stairs? Make a few. It's easier than placing or mining blocks to get around! Stairs are a little tricky to use, but generally, just face the direction you want to go and right-click the block at your feet. Diagonals work too. To continue a set of stairs, or change direction, stand on the last block facing the direction you want to go (the next block MUST be air). Right click the block you are standing on. Stairs down are a little finicky. You'll need to click them right on the last block on a ledge. Play around with them (and the other stairs) a bit in creative mode. You'll get it. Another hint: stairs stop when they hit non-air, so the next block in the step direction must always be empty.

You'll need an Experience Orb Catcher to make Experience Armor and an Experience Sword. It's worth it. Pretty awesome effects!

You'll also need an Experience Orb Catcher to make an Experience Tree Seed. It's a must! Otherwise, where will you put the dance floor for your Girlfriend to dance?

Ender-Pearl and Eye-of-Ender blocks are used to build a Cephadrome summoner. 3x3 square of Ender-Pearl blocks. Place an Eye-of-Ender block on top in the middle. Then top it all off with an Extreme Torch. Poof! Ender-Pearls can be most easily aquired by killing Endermen, of course. But they reside in The End. How can you get back home with all your loot?

Fine. Wah. For those of you not manly enough to brave The End to get enough Ender-Pearls to build a proper Cephadrome Summoner, Diamond Blocks instead of Ender-Pearl blocks will work as well... 9x9 Diamond Blocks, Eye-of-Ender block on top in the middle, then top it all off with an Extreme Torch. Poof! Ride your Cephadrome to VICTORY!

Amethysts can be found, rarely, deep underground. They make some pretty cool purple tools!

Rubies are a miner's equivalent to a Dragon. Only a seriously manly miner can mine rubies! Why? Because they only appear directly under a lava pool! Yep. Mine that Ruby Ore block, and the lava lets loose... Good luck with that! And yes, they're fairly rare...

Rubies can be used to make tools and armor. Also a sword. But the best reason to go mining for rubies, is: a ThunderStaff!

The ThunderStaff!!!! Oh yeah. Warriors have had all the glory of late. It's about time we miners showed them how to kick some real butt! A ThunderStaff has about 50 uses until it is drained. Luckily, all you have to do is wait for a Thunderstorm, and it will recharge automatically.

Make sure to hunt down a few Stink Bugs to make yourself a Kraken Repellent! Then just place it on the ground before you start killing Attack Squid. Protects about a 10x10 block area, so don't get too far away!

No, you cannot craft shoes. You may be many things, but Cobbler is not one of them.



MORE FOOD

Fish that live in lava provide fire protection and hunger points when eaten.  No, you don't need to cook fish that were caught in lava. Yes, you can eat lava fish any time. You don't need to be hungy. Great stuff to take along to the Nether!

A bag of popcorn gives more health than just the popcorn that went into it.  No, you can't have just salt on your popcorn! Yuck.

Corndogs have an amazing amount of healing/hunger power. I love corndogs! :)

Try the Strawberries. They're delicious.

Corn is yummy too. Great for eating raw, or planting to grow more.

Butter Candy! Try some! Catch a sugar buzz! :)

BACON!!! Yes!!! The all-time most gloriously wonderful food in the world is here! You've got to try it!

Taking Butter Candy and Bacon to battle can be a great help. Try some and find out why!



PLANTS AND TREES

Strawberry plants can be found in the forest. Yes, you can transplant them to your garden. You don't plant strawberries, you plant the little strawberry plants!

Sky Trees are cool as sh**! They're increbibly delicate. Break one log, and they all fall! Sky Tree logs can be used to build all sorts of stuff, then one little hit, and poof! Sky Tree logs turn into Oak Planks if you put them on the Crafting Table. Need a lot of wood fast? Find a sky Tree. You'll only need one! But be careful when building with Sky Tree logs...

Did I mention the Duplicator Tree? See if you can find one. Place a valuable block or two near the base. Just like having a Zerox machine... Yes, you can chop down a Duplicator Tree and replant the logs on dirt blocks.  It will grow again! And then it will duplicate whatever is nearby... Can be VERY useful for replicating rare stuff!!! They're kind of short, and tend to grow in the Brown and Red Ant worlds.

Corn plants can be found in the plains. Wait until the corn ripens to harvest it. Corn can be planted in your garden to grow corn plants. No, bone meal doesn't work on corn plants. Tough noogies. They are worth the wait!

Put a regular old run-of-the-mill apple on the crafting table to get yourself an Apple Tree Seed. Right-click your Apple Tree Seed on a dirt/grass block to grow an Apple Tree! Reap your rewards... then plant an orchard, and come back often to pick up the drops!

Plant an Experience Tree Seed. Wait. Might be quick. Might be slow. Who knows. But once it grows up, prepare to be amazed. Build a dance floor, hang a few lanterns, get yourself a few girlfriends, and prepare to have some fun! When night falls, the party begins...  Remember, as with all MC plants, you need to be near them for them to grow. Plant one near home base, and then forget about it.

Moth, Butterfly, and even Mosquito plants can be dug up and replanted.

Apple trees are prolific producers. You'll never be hungry if you plant an apple tree.

Wind Trees always point the same direction, kind of like a compass.

DON'T plant that "OMG! No! Don't do it!" magic apple! I warned you! ;) Well, yes, you really should, but read the WARNINGS section below! And lastly, don't forget to explore INSIDE too...

Firefly Plants spawn Fireflies at night. Beautiful to watch. Don't plant too many... They're rather prolific!



CRITTERS AND MOBS

Mosquitos can be seriously annoying. Mosquitos spawn from mosquito plants, usually found in the swamp. And just like in real life, they tend to follow you around and buzz your ears once they find you!

Moths are harmless, and spawn from Moth Plants at night. Moths like to hang out near torches, just like real moths! Kind of nice to just sit back with a cold one and watch the moths fly around the torches...

Butterflies are harmless as well, and spawn from Butterfly plants during the day. Make a butterfly garden. It's relaxing and colorful...

Brown and Rainbow ants are fairly harmless. Red ants are not!

The WTF? eats stone. It's slow, and hates everything. May be usefull if you're too lazy to mine yourself... Hey, what do you think made all those caves anyway?

CaveFishers are annoying. Just a random mob down in caves.

Baby Scorpions are annoying too. They spawn in deserts. But at least they have the decency to drop gold/uranium/titanium nuggets!

Dragonflies eat ants, mosquitoes, butterflies and birds! They also attack Horses. And just like baby scorpions, they drop gold/uranium/titanium nuggets!

Cryolophosaurus is annoying. But tastes like chicken! Spawns in the Red Ant World.

Baryonyx just eats grass. Harmless, kind of like a cow. Tastes great too!

Alosaurus is hungry. Best to stay away from him in the Red Ant World.

How about that WaterDragon! Is he cool or what? :)  Shoots waterballs and fireballs. Not friendly! Drops some super nice Iron items!

Birds sometimes drop a ruby when killed. Good luck with that though. Birds are small and fast!

Basilisk lairs have the best loot! Sometimes more than you can carry! Entrance is on the surface in the Red And World. Kinda pyramid shaped. Can you get through the maze without cheating? Of course, you need to defeat the Basilik first. He seems to like Jungles too. The Basilisk drops all sorts of Emerald items.

Giant Emperor Scorpions spawn in the desert. Nobody messes with the Emperor. Run. Just. Run. The Emperor Scorpion drops all sorts of Diamond items, but it's not worth getting killed over. Is it?

Robots spawn in the Village (Rainbow Ant) world. Nothing to say here but GTFO!!! Get out before sundown. It's your only hope. Watch for the Robo-Warrior. He sometimes drops a Ray Gun!

The Alien. Yeah. THE Alien. Not just any alien. But THE Alien. 'Nuff said. Bring clean underwear with you while mining in the Red Ant World! Lol! What? Oh. Dang. Sorry to hear that. Seems the Alien has decided to go home. Unfortunately though, he appears to have dropped off his delinquent little half-brother... Not. Good.

Attack Squids can cause temporary blindness... and they do have some nice rare gold item drops... but you can't risk killing them yourself. Really. If killed by a player, there's a chance they'll call home... for DAD. Yeah. You don't want to deal with Daddy Squid. Unh uh. No no. Find yourself a Girfriend or a Baby Dragon, or even better yet a Lizard, to kill Attack Squids for you. Well, ok. Go ahead. Kill Attack Squids if you want. Just remember to run when Daddy comes after you... That or make sure you have a Kraken Repellent handy!

Lizards are here to help you fight off the Attack Squid invasion. Ink sacks attract lizards. Ink sacks will also temporarily tame a Lizard. They are lizards after all, and they forget they're tamed after a while. Still, this creates a moral dilemma: should you really be killing innocent civilian squids just to get ink sacks?

What? You killed a few Attack Squids? It started to rain and thunder? I told you not to. Only one thing to do now... Put down your weapons. Take off your armor. Bend over. That's right. As far as you can. Now kiss your a** goodbye. ROTFLMAO! I told you not to mess with the Attack Squids. Now you've brought on the wrath of Daddy Squid, or as you might otherwise know him: THE KRAKEN!!!! And you better hope he didn't bring a few friends! ROTFL!!! Don't say I didn't warn you!!!

THE KRAKEN is exceptionally hard to kill without a Cephadrome or a Dragon, even in creative mode. But it is actually possible. You just have to get clever and prepare ahead of time. There are ways to kill them. A word of caution though: You know how the Attack Squids called home for help? So will a severely wounded KRAKEN if he gets away. Right. Failure is not an option. The Kraken drops all sorts of goodies. Tons. If you can kill him, that is.

Cephadrome to the rescue! Yeah, baby. No reason to run from the Kraken any more.... Some seriously kick-ass help is here. FEED THE CEPHADROME BEFORE YOU TRY TO GET ON IT! Yes, the Cephadrome is mountable and flyable. No saddle needed. No taming needed. Just feed it some raw beef, raw chicken, or raw pork first. If it is hungry when you try to mount it, it will eat YOU instead! Right click with empty hand to mount (AFTER FEEDING IT!). Left Shift to dismount. To summon a Cephadrome you need to build a summoner. Place 9 Ender-Pearl Blocks (or diamond blocks if you really can't find enough Ender-Pearls) in a 3x3 square. Place one real Eye-Of-Ender Block on top in the middle. Now place an Extreme Torch on top. Poof! Cephadrome summoned! Another torch, another Cephadrome. You cannot tame a Cephadrome. But it will tolerate you flying it for a while. When you get off, it will wander away and de-spawn. Cephadromes do not spawn in the wild. Flight controls are limited. It's a giant lizard. Get over it. SPACE key goes UP. Letting off the SPACE key goes down. "W" key to go forward. "S" key to slow or stop. Why fly a Cephadrome? Because it kicks Kraken butt, that's why!!! Just fly your Cephadrome right straight at the Kraken's head and let the Cephadrome have a go at it! Well, that's just great, but just how the heck are you supposed to get all those EnderPearls??? Hint: Red ants spawn in the End! It's not one-way any more! That, or you can take a few ant nests with you... Or cheat and use Diamond blocks instead of EnderPearl blocks. It's ok.

Fireflys, or Lightning Bugs as some of us call them, are harmless. They bring a special beauty to the night. Find a couple Firefly plants and place them near your home base. Nighttime never looked so good. Plant a few atop a giant spiral tree for Christmas!

The Bee. Yeah. Ow. But it does have some good and quite delicious drops. Good luck with this one though. He's nasty! Jungles and Forests just got a lot more hazardous!

Do you hate spiders because they like to jump on your head? Then you're really really really going to hate the Jumpy Bug. It's not just jumpy though, it's also HUGE, and deadly. Drops some nice Amethyst stuff on occaision. Witches are the least of your worries in swamps now! Lol!

Spit Bugs are the Jumpy Bug's Henchmen. Although they're not just wanna-be's. They're almost nasty enough to be their own Boss Mob!

Stink Bugs inhabit the Forest and the Jungle. They're harmless. Sort of. At least they're useful for crafting your Kraken Repellent!



TAMEABLE CRITTERS

Camarasaurus is tameable. They are about the cutest, friendliest little critters ever.  They don't do much except eat grass, leaves, vines, and cactus, but they do have a tendency to stick their nose in your face for a quick loving and trusting smooch.  If you want some warm fuzzies, then Camarsaurus is the pet for you.  Camarsaurus is found only in the Red Ant World. Red apple to tame. Cannot be un-tamed!!!  Tail speed indicates health and/or sitting.

Hydrolisc is also tameable. Pretty cool looking too! Keep an eye out for them in swamps!  These critters give you extra health points when you need them. Yes they do.  Watch your health bar next time you've got one of these as a pet and you get hurt!  Extremely useful when battling mobs. Better than a potion of regeneration...  They love water, and restore their health (and yours) quickly when in or near it.  Raw fish to tame. Dead bush to un-tame. Ruffles on the head indicate health.  Tail wagging indicates sitting or not.

Velocity Raptor is tameable too! He'll double your ground speed. It's like having a permanent speed potion! Red apple to tame. Dead bush to un-tame.  Generally found only in random places in the Red Ant World. Feathers indicate health and/or sitting. You can toggle the speed effect on and off by making him sit to turn speed off, and then another Red Apple to turn speed back on.

Spyro is tameable as well. Though he's kind of annoying and catches everything on fire.  Raw beef to tame. dead bush to un-tame. Don't bother trying to kill him.  He's virtually indestructible. He should also be able to keep up with you when you're flying around in creative mode. Great little pal to have around, unless you don't like fire...

Dragon: Yes! The Baby Dragon grows up! The time is random, but when/if he does, you've got yourself a tamed Dragon that you can ride! Untamed Dragons are tameable as well, but they take a fair amount of raw beef to convince. Right click with empty hand to mount. Right click with empty hand to dismount. No saddle needed. Same flight controls as the Cephadrome (which you should have already read!). Dragons and Baby Dragons can now act a little more civilized and not set everything on fire all the time. Right click with an Ice Block, and it's "flame off"! Right click with Flint and Steel to give them their mojo back (flame on)! Dragons can be supercharged. Yeah. If you're feeling seriously destructive, right click your dragon with some Gunpowder! Explosive Fireballs! Wow! Click with FLint and Steel to switch back to regular Fireballs after you've thouroughly destroyed your surroundings... If you really, really, really, miss your Baby Dragon, try right clicking your Dragon with a diamond. Poof. He will un-grow! And yes, a Baby Dragon that was un-grown can grow up again instantly if right-clicked with another diamond. Dragons can/should also be used to fight Krakens and MOTHRA! SPACE key goes UP when flying your dragon. Right-click with a random item to make him sit. 

Dragon update: You shoot the fireballs! Yeeeeeaaaaah!!! While flying, the 'A' key shoots small fireballs, and the 'D' key shoots big explosive fireballs! Pyromaniacs rejoice!!!!

Dragon update: You can feed your pet Dragon a snowball to change him into a White Dragon! Feed him a piece of coal to change him back.

Lizards can be tamed, temporarily, with ink sacks. Lizards like to kill Attack Squids. That's what they do.

Chipmunks can be tamed with a Red Apple. Untame with a Dead Bush. What are they good for? I don't know. They're just funny.

Gazelles can be tamed with a Red Apple. Untame with a Dead Bush. What are they good for? I don't know. They're just cute.

Ostrichs can be tamed with a Red Apple too. Untame with a Dead Bush. What are they good for? Well, riding of course! Woohoo! Your amazing Ostrich can run up and down walls and trees and won't get hurt when he falls. Pretty darn useful. You can find them in the desert during the daytime. The coolest thing though, is you don't need to tame it before riding it! Just hop right on. If you do tame your Ostrich, you can make him sit in the usual manner, but only if he's on sand, gravel, grass, or dirt. You'll see why! 'W' for forward. 'SPACE' to jump!

All Tameable critters that are yours, including your girlfriends, that are within a couple dozen blocks, and are NOT sitting, will automatically teleport with you to and from the Ant Worlds.




GIRLFRIENDS

Yes, there's a lot to read here. What did you expect? Girls are com-pli-cat-ed! :)

Right-click a Girlfriend with a Red Rose to tame her. May take more than one, or a dozen!

Right-click with a Dead Bush to break up and untame them.

Yes. Yes you can. Unlike real life, you can make your girlfriend 'stay', and shut up!  Give her a diamond to hold. Presto. She stays and is quiet...

Also unlike real life, yes, your girlfriend has a 'mute button'. Right click her with a Ruby. To re-enable her voice, right-click her with an Amethyst.

Right-click with an item, and she will hold it. Right-click with an empty hand, and she will return her item. Right-click both with items, and she will trade.

No, she CANNOT use a bow. She throws shoes. Shoes are deadly against creepers. Yes, you can throw shoes too. Shoes thrown by Girlfriends will not hurt Players. Just like real life, Girlfriends seem to have a infinite supply of shoes.

Yes, they can use swords! Give her one. Really. She won't hit you. Trust her.

No, armor would just mess up her outfit. A Girlfriend has 50 health points to make up for her refusal to wear armor.

Girlfriends will self-heal over time. Right-click with food, and they heal appropriately. Right-click with red rose, and they heal instantly.

Hold a red rose and they will follow closely.

Right-click with yellow rose, and she will change clothes! There are 41 different outfits. Right-click with yellow rose while wet, and she will change bikinis!  There are 18 different bathing suits.

No, you cannot mess with someone else's Girlfriend! Jerk.

Girlfriends are immune to fire, because the code is too ridiculously complex and needs to be completely rewritten to avoid even simple things like cactus. That's why everything in the Nether is fire resistant too.

Girlfriends like to swim in lava. Girlfriends will not drown, because the AI software doesn't always work right.

Girlfriends HATE CREEPERS and WILL ATTACK them!!! But they aren't always perfect. Sometimes they miss one.

Yes, you can take your girlfriend to the Nether:
	1. She will not follow you to the Nether, but...
	2. place blocks in front of the portal to make a level entrance.
	3. hold a red rose to bring her close to the portal.
	4. push her in!
	5. Get her back out the same way.

Sometimes Girlfriends may refuse to come back from the Nether, no matter what you do. Try shutting everything down and restarting. This usually fixes the problem so you can get her back out.  It's not just girlfriends. Tamed cats seem to have this problem too. You may (will!) find it helpful to build some sort of controlled access (like a gate!) around your Nether portal to keep your Girlfriend from  wandering in on her own.

Girlfriends do not attack Endermen, Zombie Pigmen, or other Players.  Yes, that means they work great in multiplayer!

Girlfriends do not usually attack things that you attack, or that attack you. Why?  Because she's not your Mother. You can take care of yourself.

Girlfriends are jealous, and will attack single girls that get too close.  Tamed girlfriends get along fine. Yes, you can have more than one: be quick, and unarm your first girlfriend before trying to tame a second one!

Girlfriends are perfect as helpers for fighting and exploring caves! Make sure you carry a few red roses for emergencies. Girlfriends can be a bit annoying while mining, but will quickly get out of your way when accidentally hit with a pickaxe. Sometimes though, making a small room (4x4 square) for her to hang out, or simply going around her, is the only thing you can do. Girlfriends are generally much quieter while mining, and will let you do your thing in peace. Girlfriends follow closely when mining, exploring caves, and when it's dark outside. She will teleport to you if you get too far away.

Girlfriends whine when they are hurt, but will compliment and be nice when at full health. Just place your crosshairs on your Girlfriend to see her health status. If you don't see her health status, then either you are too far away, or she is not your girlfriend.

If you don't like the skins provided, you can always download new ones from one of the many skin sites or make your own. Just rename and replace the skin files in the mod zip. Should be obvious how to name them.  girlfriend[0-40].png and bikini[0-17].png.

Dieing single Girlfriends drop shoes. Dieing tamed Girlfriends drop red roses, shoes, and whatever they were holding.

Yes, you can give an Ultimate Sword to your Girlfriend. In fact, you SHOULD!!!

Did I mention they dance? Of course they do. BUILD A DANCE FLOOR. Ground level (not raised or sunken). At least 5x5 (7x7 is a nice size) of: diamond, emerald, gold, uranium or titanium block. Best built under an Experience Tree. Party Time! You'll see why. It's totally worth it! Don't forget to hang a few lamps and plant a few moth plants too! Time to use those Girlfriend Spawn Eggs you've been saving. The action starts  after dark, late at night... BYOM. (Bring Your Own Music)




THREE NEW DIMENSIONS!


Right-clicking a brown ant will take you to Utopia. It's a a beautiful world without mobs.  Well, yes, there might be a couple, but all underground. They don't spawn above ground.  And there are Wind Trees, that always point the same direction, so you don't need a compass!  And  there are Sky Trees, which look like they grow forever and touch the sky!  Apple Trees. And the Ginormous Trees. Wow... It's a beautiful, calming, peaceful world.

Bored with nice and calm? Try right-clicking a Red Ant. But bring clean underwear!!!  The mining is awsome in the Red Ant world. Tons and tons  of stuff underground!  Mining like you've never seen it before, especially if you like Lapis Lazuli!  Oh, and yeah, almost forgot. Watch out  for Dinosaurs!!!! ;) Don't forget to look up. That could be fatal too.  Or down. Or all around.  All sorts of stuff everywhere in the Red Ant World. It's just not a safe place.

Or perhaps you're tired of mining and fighting mobs? Try a Rainbow Ant. Villages galore! Loot and pillage to your heart's content. Just don't stay past sunset. Seriously. Robots will appear. Nasty Robots. Very very nasty robots. No. You alone cannot save the village from the utter devastation and mayhem that will undoubtably result. No. Not even with your Ultimate Sowrd and Ultimate Bow. That's how nasty they are. You'll need a friend or two to help you in multi-player mode. Better to just edit the config file and disable the Robots. But if you do decide to give it a go... watch for the ray-gun drop! Wow!

Yes, your Girlfriend and other pets will automatically teleport to the ant worlds with you.  Unless you've told them to sit, of course.

Be patient with the Ant Worlds. Sometimes they can take a while to generate the first time.  Java isn't the speediest of languages! After the initial generation, you should be ok. Just remember, it's not hung, it's generating... This can be especially long when generating a Brown Ant world the first time. You'll see why.



THINGS YOU SHOULD (or maybe shouldn't!) DO

Plant an Apple Tree.

Chop down a Sky Tree.

Plant a Magic Apple, or two, or three (OMG! No! Don't!).

Find a Duplicator Tree, and duplicate a diamond block!

Find a Basilisk maze, and get through it without cheating.

Visit each of the three Ant Worlds.

Survive a night in the Rainbow Ant World. Can you save the Village?

Go mining in the Red Ant World.

Plant a moth garden and some torches in the Brown Ant World. Kick your feet up and relax a bit.

Plant an Experience Tree.

Get yourself a Girlfriend, and give her an Ultimate Sword.

Make a dance floor under an Experience tree and stay up late dancing with your Girlfriend.

Make yourself a complete set of Ultimate Armor, tools, and weapons.

Tame a Hydrolisc.

Find at least one of each of the Ancient Dried Ores!

Defeat a few of the major mobs: Water Dragon, Basilisk, Emperor Scorpion, Alien's little brother, Robo-Warrior, Kyuubi...

Take on an Emperor Scorpion with a sword. Yeah. No Ultimate Bow. No cheating!!!

Go fishing in the Nether with an Ultimate Fishing Rod.

Find something fun to do with Lava Foam.

Ride a Hoverboard!

Try using a Miner's Dream in the Red Ant world.

Make a bag of Popcorn.

Make a Corn Dog!

Mine some rubies and make yourself a Thunderstaff!

Ride a Dragon and kill MOTHRA!

Make a Cephadrome spawner.

Ride a Cephadrome and kill a Kraken!

Ride a Cephadrome at night, really slow, really low. It's like riding a mob-mower!

Make some Bacon!

Try some Sugar Candy!

Build a Home Base in a Ginormeous Tree in the Brown Ant world, take a moment to watch the Fireflies at night. They're gorgeous!

Find a Ruby Bird Dungeon - only in the Brown Ant World.

Did you find at least two of the six new dungeons?

Get over your fear of bees and go kill one! Yeah, that one. The BIG one.

Ride an Ostrich!

Kill a Jumpy Bug with a sword!

Make a Kraken Repellent, and go nuts on the Attack Squid!




WARNINGS

***WARNING***

MAGIC APPLE - OMG! No! Don't even think about it!

	Hints (for those silly enough to try it anyway):

	Get far far away from everything. Very far. Very very far. 
	Out in the middle of the plains.
	Make sure no other players or anything of value is within at least 40 blocks!
	Put a torch on the ground at your feet. You'll need it. You'll be glad you did.
	Make sure you have at least a diamond pickaxe handy. Double-check your inventory.
	There is a small chance you may need it. Usually though, just a regular axe will do.
	Right-click the Magic Apple on a grass block NEAR YOUR FEET.
	If you don't get the 'poof' and visual effects, you didn't click a grass/dirt block.
	If you did, just hang in there and wait a bit. 
	DO NOT MOVE!
	The fans on your computer should be hitting overdrive about now.
	The surprise may take 10-20 seconds to generate. It's BIG. It's huge. It's MASSIVE.
	If you are on a server, it may even log you out. Wait a minute or two, then log back in.
	SURPRISE!  :)
	Did you look all around, and inside too? 
	The platforms on the sides are there for a convenient reason!
	Yes, there are a few random variations. Try it again!
	Did you get a sqaure one? Or was it more circular?
	What kind? Did it have chests and Golems?
	Enjoy!
	


***WARNING***

Experience Trees are rather large too. Make sure you have ample space!


***WARNING***

Hoverboards are addictive! Yeah man! Make yourself a hoverboard and hop on!  Right click to dismount. It will stay put by itself. Or attack  with your hand until it turns into an item you can carry. Whatever. Once you get on, you really won't want to get off! Holding the SPACE key makes you go even faster. Only two directions: forward and reverse. Right-click with your Ultimate Sword to change colors. There are 10. Want to try something really super cool? Find yourself a nice big steep mountain.  Yes, one from the Extreme Hills will do just fine. Go Ahead. Slam into that sucker at full throttle! Yeah. Trust the onboard automatic collision avoidance system to use that mountain as a gigantic ramp! Yowowowowow wow wow wow eeeeeeeeeeeeeee........  Yeah, you might take a little damage from too many g's, but who gives a ....? It's fun as ....!!!!! :) Oh, yeah... Take a compass with you! It's seriously easy to get lost real fast.


***WARNING***

Minecraft is really not made to handle flying critters. There can be severe lag, especially in the Brown Ant world with all the Ginormous Trees. Stick to a relatively small area when flying Dragons and especially Cephadromes, or loading up chunks will eat your machine alive. 


***WARNING***

Make sure you're out of the Rainbow Ant World before dark. You've been warned!


***WARNING***

Oh geez. Does THE KRAKEN really need a warning? You should just know better...



DISCLAIMER AND CAUTIONS


DISCLAIMER: As with anything Minecraft/Forge, and especially Java, nothing is guaranteed to work 100% of the time. In fact, some things may  just refuse to work at all. Kind of annoying, but hey, I test the bejeepers out of my code. Not everyone else does. Speaking of annoyances, here are a couple important ones:

CAUTION: Teleporting between worlds is not 100% safe. There is a bug which steadfastly refuses to report the correct block ID for the position  requested. In other words, you could end up buried in dirt or stone. Have a pick handy the first few times back and forth until you find a safe  place.

CAUTION: Swapping items too fast with a Girlfriend can lead to mysterious loss of item. Probably has something to do with packets getting  out-of-sync with the server. Wait a couple seconds between swaps/gives/takes.

CAUTION: Flying around in creative mode with your Girlfriend trying to follow you can lead to her mysterious disappearance. :(  Give her a diamond to hold first. Then she should stay put.

CAUTION: Magic Apples are addictive! :)

BEWARE: MOTHRA!





ABOUT THESE MODELS

THERE ARE NO STOLEN MODELS HERE!

All models were either:
1) made by me
2) sent to me, or
3) posted PUBLIC on Techne.

A model is less than 20% of the work. Preparing the model to be animated, then animating the model, then coding the entity, giving it some personality, integrating it into the game, and testing, testing, testing, are by far the lion's share of the work.

And guess what I do with all that work I add to the critter...

I post it all back PUBLIC on Techne, free for everyone to use.
Yes, I do. Animation and entity included.
Go ahead. Check.

It's called 'sharing'.

Next person to accuse me of stealing gets:

if(player.getPlayerName().equals("Insert Playername Here")) {
           doLightningBolt(player.posX, player.posY, player.posZ);
}


Thank you, and have a nice day!
:)



Model Credits:

I went back to search for the original model creators on Techne, and could not find most of them. If you created one of these models, please send me your username and the link to the original posted model on Techne. I will happily add you in here!

Kraken:  Pampanapa
Lizard:  Pampanapa
Kyuubi:  Darkstar108
Robo-Warrior:  Pixel
Water Dragon:  BlueEyes
Dragon:  BlueEyes
Cephadrome:  Heltrato
Emperor Scorpion: LordBowin
WTF:  Kitsu
Bee:  Pampanapa
Chipmunk:  CakeBake
Gazelle:  CakeBake
Jumpy Bug: LordBownin
Spit Bug: LordBowin


Robo-Gunner:   ?
Robo-Pounder:   ?
Bomb-omb:  ?
Dragonfly:  ?
Baby Dragon:  ?
Cavefisher:  ?
Velocity Raptor:  ?
Camarasaurus:  ?
Baryonyx:  ?
Cryolophosaurus:  ?
Alosaurus:  ?
Attack Squid:  ?
Firefly:  ?
Stink Bug:  ?


All the Rest: Me!



HELP! SOMETING IS NOT WORKING!


Do you have a recent version of Java? They're up to 7-something. Please check and update if necessary. Please note that the 64-bit version of Java must be manually downloaded and installed. Java people are still in the stone age, and haven't figured out that normal people have moved on to 64-bit platforms.

Are you running a reasonably recent version of Forge? Please go to files.minecraftforge.net and get the latest RECOMMENDED installer. This version of OreSpawn was built and tested with Forge 9.10.0.804.

Are some of your mods out of date? Maybe from 1.5.2? Please either update or remove them.

OK. 9 times out of 10, the problem is another mod that does not play nicely with others. The easiest thing to do, is to remove all the mods except OreSpawn and make sure it works. Then add back your other mods one at a time until you find the culprit. There may be more than one, so keep adding them back one at a time.

Sometimes, you can make mods work together even if one of them won't play nice. If the error is a conflicting item/block/dimension ID, then OreSpawn let's you change it's range. Edit the ./minecraft/config/OreSpawn.cfg file with your favorite text editor. First try changing the BaseBlockID number. This will change the block/item ID range for OreSpawn. It defaults to 2020. Try changing it to a much bigger number, like 10000. If the problem is conflicting dimension IDs, then look for the DimensionID fields in the config file. Try changing them. Note that they MUST be in the range of 2 to 12, inclusive, and must all be unique.

If you have a MAC or an XBOX, you're on your own. Sorry. Try google.

How do you install Forge? Ask google.

How do you install mods? Ask google.



BUGS:

PLEASE report bugs on the OreSpawn blog, here:
http://www.planetminecraft.com/blog/orespawn-mod/

If you don't tell me about them, I may not ever know, and I won't be able to fix them.
I hate bugs because they detract from the overall experience of the game.
So please do report them!
Thanks!




CREDITS

A big THANK YOU to those who provided models and textures! Yes, while not all of the critter models are my own, all the animation and  entities that go with them are 100%. But again, thank you for your artistry, and here they are, not just pretty pictures anymore... they're...  ALIVE!!!

To Nico Bergemann for his nice clean implementation of player input packets!

AND EXTRA CREDIT 

To Jess for her fantastically vibrant voice!!!!

AND EXTRA SPECIAL CREDIT

To AnimalTipper, my son, for all the great ideas!

To everyone else who has contributed their great ideas too!




Enjoy!


Richard H. Clark
TheyCallMeDanger




