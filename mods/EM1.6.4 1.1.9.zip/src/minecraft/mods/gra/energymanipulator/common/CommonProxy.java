package mods.gra.energymanipulator.common;

import mods.gra.energymanipulator.client.gui.GuiEnergyContainer;
import mods.gra.energymanipulator.client.gui.GuiEnergyManipulator;
import mods.gra.energymanipulator.common.event.FlyingRingEventReciever;
import mods.gra.energymanipulator.common.gui.ContainerEnergyContainer;
import mods.gra.energymanipulator.common.gui.ContainerEnergyManipulator;
import mods.gra.energymanipulator.common.handler.tick.FlyingRingTickHandler;
import mods.gra.energymanipulator.common.tileentity.TileEntityEnergyContainer;
import mods.gra.energymanipulator.common.tileentity.TileEntityEnergyManipulator;
import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;
import net.minecraftforge.common.MinecraftForge;
import cpw.mods.fml.common.network.IGuiHandler;
import cpw.mods.fml.common.registry.GameRegistry;
import cpw.mods.fml.common.registry.LanguageRegistry;
import cpw.mods.fml.common.registry.TickRegistry;
import cpw.mods.fml.relauncher.Side;

public class CommonProxy implements IGuiHandler {
	public void registerRenderInformation() {
	}

	public void registerTiles() {
		GameRegistry.registerTileEntity(TileEntityEnergyManipulator.class,
				"gra.tileentityem");
		GameRegistry.registerTileEntity(TileEntityEnergyContainer.class,
				"gra.tileentityec");
	}

	public void registerBlocks() {
		GameRegistry.registerBlock(EnergyManipulator.blockEnergyManipulator,
				"energyManipulator");
		GameRegistry.registerBlock(EnergyManipulator.blockEnergyContainer,
				"energyContainer");
		GameRegistry.registerItem(EnergyManipulator.itemEnergyBattery,
				"energyBattery");
		if (Boolean.parseBoolean(EnergyManipulator.getOptions("enableflyring"))) {
			GameRegistry.registerItem(EnergyManipulator.itemFlyingRing,
					"flyingRing");
		}
	}

	public void addNames() {
		LanguageRegistry.addName(EnergyManipulator.blockEnergyManipulator,
				"Energy Manipulator");
		LanguageRegistry.addName(EnergyManipulator.blockEnergyContainer,
				"Energy Container");
		LanguageRegistry.addName(EnergyManipulator.itemEnergyBattery,
				"Energy Battery");
		if (Boolean.parseBoolean(EnergyManipulator.getOptions("enableflyring"))) {
			LanguageRegistry.addName(EnergyManipulator.itemFlyingRing,
					"Flying Ring");
		}
	}

	public void addRecipes() {
		int[] emrecipe = EnergyManipulator
				.stringToCraftingArray(EnergyManipulator.getOptions("emrecipe"));
		int[] ecrecipe = EnergyManipulator
				.stringToCraftingArray(EnergyManipulator.getOptions("ecrecipe"));
		int[] ebrecipe = EnergyManipulator
				.stringToCraftingArray(EnergyManipulator
						.getOptions("ebatteryrecipe"));

		ItemStack[] emStack = EnergyManipulator
				.craftingArrayToItemStack(emrecipe);
		ItemStack[] ecStack = EnergyManipulator
				.craftingArrayToItemStack(ecrecipe);
		ItemStack[] ebStack = EnergyManipulator
				.craftingArrayToItemStack(ebrecipe);

		// Energy Manipulator
		GameRegistry.addShapedRecipe(new ItemStack(
				EnergyManipulator.blockEnergyManipulator), "abc", "def", "ghi",
				'a', emStack[0], 'b',
				emStack[1], 'c', emStack[2], Character
						.valueOf('d'), emStack[3], 'e',
				emStack[4], 'f', emStack[5], Character
						.valueOf('g'), emStack[6], 'h',
				emStack[7], 'i', emStack[8]);

		// Energy Container
		GameRegistry.addShapedRecipe(new ItemStack(
				EnergyManipulator.blockEnergyContainer), "abc", "def", "ghi",
				'a', ecStack[0], 'b',
				ecStack[1], 'c', ecStack[2], Character
						.valueOf('d'), ecStack[3], 'e',
				ecStack[4], 'f', ecStack[5], Character
						.valueOf('g'), ecStack[6], 'h',
				ecStack[7], 'i', ecStack[8]);

		// Energy Battery
		GameRegistry.addShapedRecipe(new ItemStack(
				EnergyManipulator.itemEnergyBattery), "abc", "def", "ghi",
				'a', ebStack[0], 'b',
				ebStack[1], 'c', ebStack[2], Character
						.valueOf('d'), ebStack[3], 'e',
				ebStack[4], 'f', ebStack[5], Character
						.valueOf('g'), ebStack[6], 'h',
				ebStack[7], 'i', ebStack[8]);

		// Flying Ring
		if (Boolean.parseBoolean(EnergyManipulator.getOptions("enableflyring"))) {
			int[] frrecipe = EnergyManipulator
					.stringToCraftingArray(EnergyManipulator
							.getOptions("flyingringrecipe"));

			ItemStack[] frStack = EnergyManipulator
					.craftingArrayToItemStack(frrecipe);

			GameRegistry.addShapedRecipe(new ItemStack(
					EnergyManipulator.itemFlyingRing), "abc", "def", "ghi",
					'a', frStack[0], 'b',
					frStack[1], 'c', frStack[2], Character
							.valueOf('d'), frStack[3], 'e',
					frStack[4], 'f', frStack[5], Character
							.valueOf('g'), frStack[6], 'h',
					frStack[7], 'i', frStack[8]);
		}
	}

	@Override
	public Object getServerGuiElement(int ID, EntityPlayer player, World world,
			int x, int y, int z) {
		TileEntity tileEntity = world.getBlockTileEntity(x, y, z);

		if (tileEntity instanceof TileEntityEnergyManipulator
				&& ID == EnergyManipulator.GUI_ID_EM) {
			return new ContainerEnergyManipulator(player.inventory,
					(TileEntityEnergyManipulator) tileEntity);
		} else if (tileEntity instanceof TileEntityEnergyContainer
				&& ID == EnergyManipulator.GUI_ID_EC) {
			return new ContainerEnergyContainer(player.inventory,
					(TileEntityEnergyContainer) tileEntity);
		}
		return null;
	}

	@Override
	public Object getClientGuiElement(int ID, EntityPlayer player, World world,
			int x, int y, int z) {
		TileEntity tileEntity = world.getBlockTileEntity(x, y, z);

		if (tileEntity instanceof TileEntityEnergyManipulator
				&& ID == EnergyManipulator.GUI_ID_EM) {
			return new GuiEnergyManipulator(player.inventory,
					(TileEntityEnergyManipulator) tileEntity);
		} else if (tileEntity instanceof TileEntityEnergyContainer
				&& ID == EnergyManipulator.GUI_ID_EC) {
			return new GuiEnergyContainer(player.inventory,
					(TileEntityEnergyContainer) tileEntity);
		}
		return null;
	}

	public void registerTickHandlers() {
		if (Boolean.parseBoolean(EnergyManipulator.getOptions("enableflyring"))) {
			TickRegistry.registerScheduledTickHandler(
					new FlyingRingTickHandler(), Side.SERVER);
		}
	}

	public void registerEventHandlers() {
		if (Boolean.parseBoolean(EnergyManipulator.getOptions("enableflyring"))) {
			MinecraftForge.EVENT_BUS.register(new FlyingRingEventReciever());
		}
	}
}
