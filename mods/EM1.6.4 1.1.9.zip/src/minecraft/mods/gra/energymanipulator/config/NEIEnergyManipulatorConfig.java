package mods.gra.energymanipulator.config;

import org.lwjgl.input.Keyboard;

import mods.gra.energymanipulator.common.EnergyManipulator;
import mods.gra.energymanipulator.nei.TooltipHandler;
import codechicken.nei.api.API;
import codechicken.nei.api.IConfigureNEI;
import codechicken.nei.forge.GuiContainerManager;

public class NEIEnergyManipulatorConfig implements IConfigureNEI {
	private static boolean isNeiLoaded = false;

	@Override
	public void loadConfig() {
		isNeiLoaded = true;
		GuiContainerManager.addTooltipHandler(new TooltipHandler());
	}

	@Override
	public String getName() {
		return "Energy Manipulator";
	}

	@Override
	public String getVersion() {
		return EnergyManipulator.VERSION;
	}

	public static boolean isNeiLoaded() {
		return isNeiLoaded;
	}
}
