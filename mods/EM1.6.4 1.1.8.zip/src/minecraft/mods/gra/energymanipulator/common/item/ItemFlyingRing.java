package mods.gra.energymanipulator.common.item;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import mods.gra.energymanipulator.common.EnergyManipulator;
import mods.gra.energymanipulator.util.EMInvUtils;
import net.minecraft.client.renderer.texture.IconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;

public class ItemFlyingRing extends Item {

	public ItemFlyingRing(int id) {
		super(id);
		this.setCreativeTab(CreativeTabs.tabTools);
		this.setUnlocalizedName("gra.flyingRing");
		this.setMaxStackSize(1);
	}

	@Override
	@SideOnly(Side.CLIENT)
	public void registerIcons(IconRegister iconRegister) {
		this.itemIcon = iconRegister
				.registerIcon("energymanipulator:itemFlyingRing");
	}

	@Override
	public void onCreated(ItemStack stack, World world, EntityPlayer player) {
		NBTTagCompound stackTag = new NBTTagCompound();
		if (!stack.hasTagCompound()) {
			stackTag.setByte("EMUpdateTick", (byte) 0);
			stack.setTagCompound(stackTag);
		} else {
			stackTag = stack.getTagCompound();
			stackTag.setByte("EMUpdateTick", (byte) 0);
		}
	}

	
	@Override
	public boolean onDroppedByPlayer(ItemStack stack, EntityPlayer player) {
		if (!player.inventory.hasItem(EnergyManipulator.itemFlyingRing.itemID)
				&& !player.capabilities.isCreativeMode) {
			player.capabilities.allowFlying = false;
			player.capabilities.isFlying = false;
		}
		return super.onDroppedByPlayer(stack, player);
	}

	@Override
	public void onUpdate(ItemStack stack, World world, Entity entity, int slot,
			boolean held) {
		if (entity instanceof EntityPlayer) {
			EntityPlayer player = (EntityPlayer) entity;
			if (!player.capabilities.isCreativeMode) {
				if (player.inventory
						.hasItem(EnergyManipulator.itemFlyingRing.itemID)) {
					if (player.capabilities.isFlying) {
						if (!stack.hasTagCompound()) {
							NBTTagCompound stackTag = new NBTTagCompound();
							stackTag.setByte("EMUpdateTick", (byte) 0);
							stack.setTagCompound(stackTag);
						}
						NBTTagCompound stackTag = stack.getTagCompound();
						byte tick = stackTag.getByte("EMUpdateTick");
						if (tick >= 20) {
							stackTag.setByte("EMUpdateTick", (byte) 0);
							int flySecondCost = Integer
									.parseInt(EnergyManipulator
											.getOptions("flycostpersecond"));

							ItemStack[] batteries = EMInvUtils.getAllISInArray(
									player.inventory.mainInventory,
									EnergyManipulator.itemEnergyBattery.itemID);
							ItemStack[] batteriesAboveMinimum = EMInvUtils
									.getAllBatteriesWithEnergyAboveOrEqual(
											batteries, flySecondCost);
							ItemStack[] batteriesAboveZero = EMInvUtils
									.getAllBatteriesWithEnergyAboveOrEqual(
											batteries, 1);
							if (batteriesAboveMinimum != null
									&& batteriesAboveMinimum.length > 0) {
								NBTTagCompound tag = batteriesAboveMinimum[0]
										.getTagCompound();
								int batteryEv = tag.getInteger("EMEV");
								tag.setInteger("EMEV", batteryEv
										- flySecondCost);
								player.capabilities.allowFlying = true;
								return;
							} else if (batteriesAboveZero != null
									&& batteriesAboveZero.length > 0) {
								int energyNeeded = flySecondCost;
								int i = 0;
								while (energyNeeded > 0
										&& i < batteriesAboveZero.length) {
									NBTTagCompound tag = batteriesAboveZero[i]
											.getTagCompound();
									int batteryEv = tag.getInteger("EMEV");
									energyNeeded -= batteryEv;
									tag.setInteger("EMEV", 0);
									i++;
								}
								if (energyNeeded > 0) {
									player.capabilities.allowFlying = false;
									player.capabilities.isFlying = false;
									return;
								} else {
									player.capabilities.allowFlying = true;
									return;
								}
							} else {
								player.capabilities.allowFlying = false;
								player.capabilities.isFlying = false;
								return;
							}
						}

						// UPDATE TICKS
						else {
							stackTag.setByte("EMUpdateTick", (byte) (tick + 1));
						}
					} else {
						ItemStack[] batteries = EMInvUtils.getAllISInArray(
								player.inventory.mainInventory,
								EnergyManipulator.itemEnergyBattery.itemID);
						ItemStack[] batteriesAboveZero = EMInvUtils
								.getAllBatteriesWithEnergyAboveOrEqual(
										batteries, 1);

						if (batteriesAboveZero.length > 0) {
							player.capabilities.allowFlying = true;
						}
					}
				} else {
					player.capabilities.allowFlying = false;
					player.capabilities.isFlying = false;
				}
			}
		}
	}
}