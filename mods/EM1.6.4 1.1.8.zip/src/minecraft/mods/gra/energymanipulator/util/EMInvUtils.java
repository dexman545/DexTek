package mods.gra.energymanipulator.util;

import java.util.ArrayList;
import java.util.List;

import mods.gra.energymanipulator.common.EnergyManipulator;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagCompound;

public class EMInvUtils {

	public static ItemStack[] getAllISInInventory(IInventory inventory,
			int itemId) {
		if (inventory == null) {
			return null;
		}
		List<ItemStack> result = new ArrayList<ItemStack>();
		for (int i = 0; i < inventory.getSizeInventory(); i++) {
			ItemStack stack = inventory.getStackInSlot(i);
			if (stack != null && stack.itemID == itemId) {
				result.add(stack);
			}
		}
		return result.toArray(new ItemStack[result.size()]);
	}

	public static ItemStack[] getAllISInArray(ItemStack[] inventory, int itemId) {
		if (inventory == null) {
			return null;
		}
		List<ItemStack> result = new ArrayList<ItemStack>();
		for (int i = 0; i < inventory.length; i++) {
			ItemStack stack = inventory[i];
			if (stack != null && stack.itemID == itemId) {
				result.add(stack);
			}
		}
		return result.toArray(new ItemStack[result.size()]);
	}

	public static ItemStack[] getAllBatteriesWithEnergyAboveOrEqual(
			ItemStack[] batteries, int aboveOrEqualEnergy) {
		if (batteries == null) {
			return null;
		}
		List<ItemStack> result = new ArrayList<ItemStack>();
		for (int i = 0; i < batteries.length; i++) {
			ItemStack stack = batteries[i];
			if (stack != null
					&& stack.itemID == EnergyManipulator.itemEnergyBattery.itemID
					&& stack.hasTagCompound()) {
				NBTTagCompound tag = stack.getTagCompound();
				if (tag.hasKey("EMEV")
						&& tag.getInteger("EMEV") >= aboveOrEqualEnergy) {
					result.add(stack);
				}
			}
		}
		return result.toArray(new ItemStack[result.size()]);
	}
}
