package mods.gra.energymanipulator.client;

import net.minecraftforge.client.MinecraftForgeClient;
import net.minecraftforge.common.MinecraftForge;
import mods.gra.energymanipulator.common.CommonProxy;
import mods.gra.energymanipulator.common.EnergyManipulator;
import mods.gra.energymanipulator.common.event.FlyingRingEventReciever;
import mods.gra.energymanipulator.common.handler.tick.FlyingRingTickHandler;
import cpw.mods.fml.client.FMLClientHandler;
import cpw.mods.fml.common.registry.TickRegistry;
import cpw.mods.fml.relauncher.Side;

public class ClientProxy extends CommonProxy {
	@Override
	public void registerRenderInformation() {
	}

	@Override
	public void registerTickHandlers() {
		if (Boolean.parseBoolean(EnergyManipulator.getOptions("enableflyring"))) {
			TickRegistry.registerScheduledTickHandler(
					new FlyingRingTickHandler(), Side.CLIENT);
		}
	}

	@Override
	public void registerEventHandlers() {
		if (Boolean.parseBoolean(EnergyManipulator.getOptions("enableflyring"))) {
			MinecraftForge.EVENT_BUS.register(new FlyingRingEventReciever());
		}
	}
}